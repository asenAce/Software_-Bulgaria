﻿using System;

namespace SoftUni.UI
{
    public class StudentAdminForm : System.Windows.Forms.Form
    {
        // ...
		private void InitializeComponent()
		{
			this.SuspendLayout();
			// 
			// StudentAdminForm
			// 
			this.ClientSize = new System.Drawing.Size(284, 262);
			this.Name = "StudentAdminForm";
			this.Text = "Students";
			this.ResumeLayout(false);

		}
	}
}
