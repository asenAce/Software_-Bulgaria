﻿namespace AttributeValidation.Models
{
    public class Weapon
    {
        public string Name { get; set; }

        public int Damage { get; set; }
    }
}
