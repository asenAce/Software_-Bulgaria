﻿namespace StructVsClass
{
    public struct ColorStruct
    {
        public byte RedValue { get; set; }
        public byte GreenValue { get; set; }
        public byte BlueValue { get; set; }
    }
}
