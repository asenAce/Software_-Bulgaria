﻿public class FiguresExample
{
    public static void Main()
    {
    }
}
