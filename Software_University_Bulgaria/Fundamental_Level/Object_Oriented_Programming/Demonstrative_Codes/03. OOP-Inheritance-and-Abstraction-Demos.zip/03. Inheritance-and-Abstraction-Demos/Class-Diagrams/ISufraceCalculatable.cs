﻿public interface ISufraceCalculatable
{
    float CalculateSurface();
}
