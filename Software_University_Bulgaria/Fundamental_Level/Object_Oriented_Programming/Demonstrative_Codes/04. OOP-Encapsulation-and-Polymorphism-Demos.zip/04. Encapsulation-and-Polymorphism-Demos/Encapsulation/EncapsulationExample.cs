﻿namespace Encapsulation
{
    using System;

    public class EncapsulationExample
    {
        public static void Main()
        {
            Person p = new Person("Bay Ivan", 73);
            Console.WriteLine(p);

            // Person n = new Person("Negative age", -5);

            // Person e = new Person("", 20);
        }
    }
}
