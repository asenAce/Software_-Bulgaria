﻿public class SpecialFigure : Circle
{
}