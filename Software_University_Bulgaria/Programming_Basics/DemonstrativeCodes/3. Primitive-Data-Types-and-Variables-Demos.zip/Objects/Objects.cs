using System;

class Objects
{
	static void Main()
	{
		object dataContainer = 5;
		Console.Write("The value of dataContainer is: ");
		Console.WriteLine(dataContainer);

		dataContainer = "Five";
		Console.Write("The value of dataContainer is: ");
		Console.WriteLine(dataContainer);
	}
}
