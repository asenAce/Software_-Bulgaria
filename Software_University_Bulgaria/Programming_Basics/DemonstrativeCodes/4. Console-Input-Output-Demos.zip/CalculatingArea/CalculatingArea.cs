using System;

class CalculatingArea
{
    static void Main()
    {
        // Console.WriteLine("First" + Environment.NewLine + "Second" + "First" + Environment.NewLine + "First" + Environment.NewLine + "First" + Environment.NewLine);
    }
}
